package com.example.cachecleaner.cleaner

object CleanerProtocol {
    const val ACTION_START = "com.example.cachecleaner.ACTION_START"
    const val ACTION_STOP  = "com.example.cachecleaner.ACTION_STOP"
    const val ACTION_PROGRESS = "com.example.cachecleaner.ACTION_PROGRESS"

    const val EXTRA_PACKAGES = "extra_packages"

    const val EXTRA_TOTAL = "extra_total"
    const val EXTRA_DONE = "extra_done"
    const val EXTRA_CURRENT_PKG = "extra_current_pkg"
    const val EXTRA_SUCCESS = "extra_success"
    const val EXTRA_FAIL = "extra_fail"
    const val EXTRA_STATUS = "extra_status"
}
