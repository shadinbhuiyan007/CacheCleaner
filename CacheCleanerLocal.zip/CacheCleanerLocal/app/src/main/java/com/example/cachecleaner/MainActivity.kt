package com.example.cachecleaner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.cachecleaner.cleaner.CacheCleanerService
import com.example.cachecleaner.cleaner.CleanerProtocol

class MainActivity : AppCompatActivity() {

    private lateinit var statusTv: TextView
    private lateinit var includeSystem: CheckBox
    private lateinit var selectAll: Button
    private lateinit var clearSel: Button
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var openAccBtn: Button
    private lateinit var listView: ListView

    private val selected = linkedSetOf<String>()
    private val items = mutableListOf<Pair<String, String>>() // label, pkg

    // Never touch these (avoid breaking system navigation / Google services)
    private val hardExclude = setOf(
        "com.example.cachecleaner",
        "com.android.systemui",
        "com.android.settings",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.android.vending",
        "android"
    )

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != CleanerProtocol.ACTION_PROGRESS) return
            val status = intent.getStringExtra(CleanerProtocol.EXTRA_STATUS) ?: "?"
            val total = intent.getIntExtra(CleanerProtocol.EXTRA_TOTAL, 0)
            val done = intent.getIntExtra(CleanerProtocol.EXTRA_DONE, 0)
            val pkg = intent.getStringExtra(CleanerProtocol.EXTRA_CURRENT_PKG) ?: ""
            val ok = intent.getIntExtra(CleanerProtocol.EXTRA_SUCCESS, 0)
            val fail = intent.getIntExtra(CleanerProtocol.EXTRA_FAIL, 0)

            statusTv.text = "Status: $status | $done/$total\nCurrent: $pkg\nSuccess: $ok  Fail: $fail"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusTv = findViewById(R.id.tvStatus)
        includeSystem = findViewById(R.id.cbIncludeSystem)
        selectAll = findViewById(R.id.btnSelectAll)
        clearSel = findViewById(R.id.btnClearSelection)
        startBtn = findViewById(R.id.btnStart)
        stopBtn = findViewById(R.id.btnStop)
        openAccBtn = findViewById(R.id.btnAccessibility)
        listView = findViewById(R.id.listView)

        openAccBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        includeSystem.setOnCheckedChangeListener { _, _ ->
            loadApps()
        }

        selectAll.setOnClickListener {
            items.forEach { selected.add(it.second) }
            (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
            Toast.makeText(this, "Selected: ${selected.size}", Toast.LENGTH_SHORT).show()
        }

        clearSel.setOnClickListener {
            selected.clear()
            (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
        }

        startBtn.setOnClickListener {
            val pkgs = ArrayList(selected.filter { it !in hardExclude })
            if (pkgs.isEmpty()) {
                Toast.makeText(this, "No apps selected", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val i = Intent(this, CacheCleanerService::class.java).apply {
                action = CleanerProtocol.ACTION_START
                putStringArrayListExtra(CleanerProtocol.EXTRA_PACKAGES, pkgs)
            }
            startService(i)
        }

        stopBtn.setOnClickListener {
            val i = Intent(this, CacheCleanerService::class.java).apply {
                action = CleanerProtocol.ACTION_STOP
            }
            startService(i)
        }

        loadApps()
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(receiver, IntentFilter(CleanerProtocol.ACTION_PROGRESS))
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(receiver)
    }

    private fun loadApps() {
        items.clear()
        selected.clear()

        val pm = packageManager
        val includeSys = includeSystem.isChecked

        val apps = pm.getInstalledApplications(0)
            .asSequence()
            .filter { ai ->
                includeSys || pm.getLaunchIntentForPackage(ai.packageName) != null
            }
            .map { ai ->
                val label = pm.getApplicationLabel(ai)?.toString() ?: ai.packageName
                val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                Triple(label, ai.packageName, isSystem)
            }
            .filter { it.second !in hardExclude }
            .filter { includeSys || !it.third }
            .sortedWith(compareBy<Triple<String, String, Boolean>>({ it.third }, { it.first.lowercase() }))
            .toList()

        apps.forEach { items.add(it.first to it.second) }

        listView.adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row = convertView ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(16, 16, 16, 16)
                    addView(CheckBox(this@MainActivity), LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                    ))
                    addView(TextView(this@MainActivity), LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                    ).apply { leftMargin = 16 })
                }

                val cb = (row as LinearLayout).getChildAt(0) as CheckBox
                val tv = row.getChildAt(1) as TextView

                val (label, pkg) = items[position]
                tv.text = "$label\n$pkg"
                cb.setOnCheckedChangeListener(null)
                cb.isChecked = selected.contains(pkg)
                cb.setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(pkg) else selected.remove(pkg)
                }
                return row
            }
        }
    }
}
