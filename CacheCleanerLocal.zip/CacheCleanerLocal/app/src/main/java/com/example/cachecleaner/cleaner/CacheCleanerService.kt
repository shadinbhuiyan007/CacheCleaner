package com.example.cachecleaner.cleaner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import java.util.ArrayDeque

/**
 * Mode-2 (Accessibility autopilot) cache cleaner.
 * Device tuned for Walton Primo GH11 where the menu text is "Storage & cache".
 *
 * Notes:
 * - This uses Settings UI automation. It is best-effort and OEM-dependent.
 * - "High-speed" is limited by UI render time; animations 0x improves speed a lot.
 */
class CacheCleanerService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    @Volatile private var running = false
    @Volatile private var job: Job? = null

    override fun onServiceConnected() {
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.flags = info.flags or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* polling approach */ }
    override fun onInterrupt() {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            CleanerProtocol.ACTION_START -> {
                val pkgs = intent.getStringArrayListExtra(CleanerProtocol.EXTRA_PACKAGES) ?: arrayListOf()
                startCleaning(pkgs)
            }
            CleanerProtocol.ACTION_STOP -> stopCleaning()
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun startCleaning(packages: List<String>) {
        if (running) return
        running = true

        job = scope.launch {
            val total = packages.size
            var done = 0
            var success = 0
            var fail = 0

            sendProgress(total, done, "", success, fail, "RUNNING")

            for (pkg in packages) {
                if (!running) break
                sendProgress(total, done, pkg, success, fail, "RUNNING")

                openAppInfo(pkg)

                if (!waitForRoot(1100)) { fail++; done++; continue }

                val openedStorage = openStorageScreenFast() || scrollOnceAndTryStorage()
                if (!openedStorage) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    shortDelay(40)
                    fail++; done++; continue
                }

                waitForRoot(650)
                shortDelay(50)

                val clicked = clickClearCacheFast()
                if (clicked) {
                    shortDelay(80)
                    success++
                } else {
                    fail++
                }

                performGlobalAction(GLOBAL_ACTION_BACK)
                shortDelay(40)
                performGlobalAction(GLOBAL_ACTION_BACK)
                shortDelay(40)

                done++
                sendProgress(total, done, pkg, success, fail, "RUNNING")
            }

            running = false
            sendProgress(total, total, "", success, fail, "DONE")
        }
    }

    private fun stopCleaning() {
        running = false
        job?.cancel()
        job = null
        sendProgress(0, 0, "", 0, 0, "STOPPED")
    }

    private fun sendProgress(total: Int, done: Int, pkg: String, success: Int, fail: Int, status: String) {
        val i = Intent(CleanerProtocol.ACTION_PROGRESS).apply {
            putExtra(CleanerProtocol.EXTRA_TOTAL, total)
            putExtra(CleanerProtocol.EXTRA_DONE, done)
            putExtra(CleanerProtocol.EXTRA_CURRENT_PKG, pkg)
            putExtra(CleanerProtocol.EXTRA_SUCCESS, success)
            putExtra(CleanerProtocol.EXTRA_FAIL, fail)
            putExtra(CleanerProtocol.EXTRA_STATUS, status)
        }
        sendBroadcast(i)
    }

    private fun openAppInfo(pkg: String) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$pkg")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(i)
    }

    private suspend fun waitForRoot(timeoutMs: Long): Boolean {
        val start = SystemClock.uptimeMillis()
        while (SystemClock.uptimeMillis() - start < timeoutMs) {
            if (rootInActiveWindow != null) return true
            delay(25)
        }
        return rootInActiveWindow != null
    }

    private suspend fun shortDelay(ms: Long) = delay(ms)

    private fun openStorageScreenFast(): Boolean {
        // Walton GH11 confirmed text:
        val byText = clickByTexts(listOf("Storage & cache"))
        if (byText) return true
        return clickByTexts(listOf("Storage"))
    }

    private fun scrollOnceAndTryStorage(): Boolean {
        val scrolled = scrollForwardOnce()
        if (!scrolled) return false
        return openStorageScreenFast()
    }

    private fun clickClearCacheFast(): Boolean {
        val byId = clickByViewIdAny(listOf(
            "com.android.settings:id/clear_cache_button",
            "com.android.settings:id/button2"
        ))
        if (byId) return true

        return clickByTexts(listOf("Clear cache", "CLEAR CACHE"))
    }

    private fun clickByTexts(texts: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (t in texts) {
            val nodes = root.findAccessibilityNodeInfosByText(t) ?: continue
            for (n in nodes) {
                if (performClickUpTree(n)) return true
            }
        }
        return false
    }

    private fun clickByViewIdAny(ids: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (id in ids) {
            val nodes = try { root.findAccessibilityNodeInfosByViewId(id) } catch (_: Throwable) { null }
            if (!nodes.isNullOrEmpty()) {
                for (n in nodes) if (performClickUpTree(n)) return true
            }
        }
        return false
    }

    private fun performClickUpTree(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        repeat(7) {
            if (n == null) return false
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    private fun scrollForwardOnce(): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst()
            if (n.isScrollable) {
                val ok = n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                if (ok) return true
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return false
    }
}
