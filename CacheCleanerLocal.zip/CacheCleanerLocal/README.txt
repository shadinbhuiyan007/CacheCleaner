CacheCleanerLocal (Mode-2 Accessibility autopilot)

1) Build with Android Studio or any Gradle-capable Android IDE.
2) Install on device.
3) Settings > Accessibility > enable "Cache Cleaner (Local)" service.
4) In app: (optional) check "Include system apps (risky)" then select apps and tap Start.

Speed tips:
- Developer options: set all animations to 0x
- Keep Settings language English (matches "Storage & cache", "Clear cache").
